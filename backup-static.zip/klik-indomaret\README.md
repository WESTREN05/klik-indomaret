# Klik Indomaret — Prototype Web App

Prototype aplikasi belanja kebutuhan harian **Klik Indomaret** untuk tugas kuliah. Dibuat dengan HTML, CSS, dan JavaScript murni (tanpa build tools), mengikuti alur metode **Waterfall**.

Tampilan mobile-first dengan app shell selebar maksimal **480px**, terdiri dari 7 halaman:

| Halaman | File | Isi utama |
| --- | --- | --- |
| Beranda | `index.html` | Alamat, pencarian, mode antar/ambil, saldo & poin, promo, kategori, flash sale, produk populer |
| Kategori | `kategori.html` | Katalog, pencarian, filter harga, urutan, promo JSM, ready di toko |
| Detail Produk | `produk.html` | Galeri, harga, varian, info toko, pengiriman, tab deskripsi/gizi/sertifikasi, produk terkait |
| Keranjang | `keranjang.html` | Pilih produk, atur jumlah, voucher, tukar poin, ringkasan, checkout, halaman sukses |
| Masuk / Daftar | `login.html` | Login, register, lupa password, show/hide password, akun demo |
| Akun | `akun.html` | Profil, saldo/poin/stamp, pesanan, alamat, pengaturan, bantuan, logout |
| Promo | `promo.html` | Klaim voucher, daftar produk harga spesial JSM |

---

## Cara menjalankan

### Opsi 1 — Python (paling gampang)

```bash
cd klik-indomaret
python -m http.server 8123 --bind 127.0.0.1
```

Buka `http://127.0.0.1:8123/index.html` di browser.

### Opsi 2 — VS Code Live Server

Klik kanan `index.html` → **Open with Live Server**.

> Halaman juga bisa dibuka langsung lewat `file://`, tetapi disarankan pakai local server supaya semua aset dan font dimuat dengan benar.

---

## Akun demo

- **Nomor HP:** `081234567890`
- **Password:** `password123`

Atau tekan tombol **Isi otomatis** di halaman login.

### Mode demo cepat

Tambahkan `?demo=1` di URL untuk mengisi keranjang dan akun demo otomatis:

```text
http://127.0.0.1:8123/keranjang.html?demo=1
http://127.0.0.1:8123/index.html?demo=1
http://127.0.0.1:8123/akun.html?demo=1
```

Isi keranjang demo: Sania Minyak Goreng 2L ×1, Ultra Milk 1L ×2, Indomie Ayam Bawang 5 pcs ×5.

---

## Fitur yang sudah jalan

- **Beranda:** banner promo, kategori, flash sale dengan countdown, produk populer, pencarian, top up saldo, ganti alamat/toko.
- **Katalog:** pencarian real-time, filter harga min/max, urutan (terpopuler, harga, rating), filter promo JSM & ready, cart bar.
- **Detail produk:** pilih varian, pilih express/ambil di toko, ganti toko, galeri warna, tab informasi, wishlist, share, tambah ke keranjang, beli sekarang.
- **Keranjang:** pilih semua/sebagian, stepper jumlah, hapus item, ganti alamat/toko, voucher (Gratis Ongkir, Diskon Gajian 40%, Member Baru), tukar poin, ringkasan diskon, metode pembayaran QRIS/Transfer/COD, halaman sukses.
- **Auth:** login, register dengan validasi, lupa password (mock), show/hide password, sesi tersimpan di localStorage, redirect ke halaman tujuan.
- **Akun:** edit profil, riwayat pesanan, pengaturan, bantuan, tentang aplikasi, logout tanpa menghapus keranjang.
- **Promo:** klaim voucher, status klaim tersimpan, grid produk promo.
- **Penyimpanan:** keranjang, user, pesanan, alamat, toko, saldo, poin, voucher, dan metode pengiriman disimpan di `localStorage`.

Semua data bersifat **mock/local** — tidak ada backend, pembayaran nyata, atau pengiriman sungguhan.

---

## Struktur project

```text
klik-indomaret/
├── index.html
├── kategori.html
├── produk.html
├── keranjang.html
├── login.html
├── akun.html
├── promo.html
├── css/
│   └── style.css
├── js/
│   ├── data.js       # produk, kategori, toko, alamat, banner, voucher
│   ├── app.js        # mesin bersama: cart, auth, header, nav, sheet, toast
│   ├── home.js
│   ├── kategori.js
│   ├── produk.js
│   ├── keranjang.js
│   ├── login.js
│   ├── akun.js
│   └── promo.js
├── assets/
│   └── products/     # tempat foto produk (lihat di bawah)
├── docs/
│   └── waterfall.md  # dokumentasi tugas: analisis, desain, implementasi, pengujian
└── README.md
```

---

## Mengganti gambar produk

Saat ini produk memakai **emoji + gradient** sebagai placeholder. Kalau foto produk dari desain sudah tersedia, simpan file JPEG di:

```text
assets/products/<id-produk>.jpg
```

Contoh:

```text
assets/products/sania-2l.jpg
assets/products/indomie-goreng.jpg
assets/products/ultra-1l.jpg
```

Nama file harus sama dengan `id` produk di `js/data.js`. Setelah file dimasukkan, gambar akan otomatis menggantikan emoji tanpa mengubah kode.

Daftar id produk ada di `js/data.js` (mulai dari `sania-2l`, `indomie-goreng`, `ultra-1l`, dan seterusnya). Selama gambar belum ada, browser akan mencatat 404 untuk `assets/products/*.jpg` di console — ini normal dan tidak memengaruhi fungsi aplikasi.

---

## Metode Waterfall

Project ini disusun mengikuti tahapan Waterfall:

1. **Analisis kebutuhan** — menentukan 7 halaman, fitur belanja, auth, keranjang, promo, dan akun.
2. **Desain** — mengacu pada desain Google Stitch (Beranda, Kategori, Detail Produk, Keranjang) lalu menambahkan halaman Login, Akun, dan Promo.
3. **Implementasi** — HTML/CSS/JS murni, komponen bersama di `app.js`, data di `data.js`.
4. **Pengujian** — uji alur tambah ke keranjang, pencarian/filter, login/register, voucher, poin, checkout, pesanan, logout, dan tampilan tiap halaman.
5. **Pemeliharaan** — perbaikan bug, penyesuaian UI, dan penyiapan dokumentasi.

Dokumentasi Waterfall yang lebih lengkap (latar belakang, kebutuhan fungsional/non-fungsional, rancangan, pengujian, kesimpulan) tersedia di [`docs/waterfall.md`](docs/waterfall.md). Isi bagian identitas (nama, NIM, mata kuliah, dosen) sebelum dikumpulkan.

---

## Catatan pengembangan

- Reset semua data demo: buka DevTools Console, jalankan `localStorage.clear()`, lalu refresh.
- Kunci penyimpanan memakai prefix `klik_*_v1`.
- Font memakai Google Fonts (Plus Jakarta Sans). Tanpa internet, browser akan memakai font fallback.
- Desain responsif: di layar lebar, app tetap di tengah dengan lebar maksimal 480px.

---

Dibuat untuk tugas kuliah. Desain referensi: Google Stitch. Prototype ini tidak berafiliasi resmi dengan PT Indomarco Prismatama.
