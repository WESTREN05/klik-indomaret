# Foto Produk

Simpan foto produk di folder ini dengan nama sesuai `id` produk di `js/data.js`.

Format yang didukung oleh kode saat ini: **JPEG**.

Contoh:

```text
sania-2l.jpg
indomie-goreng.jpg
ultra-1l.jpg
bimoli-2l.jpg
telur-10.jpg
```

Setelah file dimasukkan, gambar otomatis tampil menggantikan placeholder emoji.
Tidak perlu mengubah HTML atau JavaScript.

Tips: gunakan gambar persegi (misalnya 600×600 px) dengan latar terang agar seragam.
